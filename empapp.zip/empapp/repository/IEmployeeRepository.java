package com.training.empapp.repository;

import java.util.Map;

import com.training.empapp.model.Employee;

public interface IEmployeeRepository {

	public void add(Employee employee);
	public void update(int id,Employee employee);
	public void delete(int id);
	public Employee findById(int id);
	public Map<Integer, Employee> findAll();
	
}
