package com.training.empapp.repository;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.training.empapp.model.Department;
import com.training.empapp.model.Employee;

public class EmployeeRepository implements IEmployeeRepository{
 
	private static Map<Integer, Employee> employeeMap;
	
	public EmployeeRepository() {
		Department dp1 = new Department(101,"Dev Team");
		Department dp2 = new Department(102,"Test Team");
		Department dp3 = new Department(103,"IT Team");
		Department dp4 = new Department(104,"Operation Team");

		
		Employee emp1 = new Employee("Vignesh", 231, 10000, dp1);
		Employee emp2 = new Employee("Venkat", 232, 15000, dp2);
		Employee emp3 = new Employee("Mani", 233, 12000, dp3);
		Employee emp4 = new Employee("Rajesh", 234, 15000, dp4);

		employeeMap = new HashMap<>();
		employeeMap.put(1, emp1);
		employeeMap.put(2, emp2);
		employeeMap.put(3, emp3);
		employeeMap.put(4, emp4);
	}
	
	public void add(Employee employee) {
		int id = employeeMap.size() + 1;
		employeeMap.put(id, employee);
	}
	
	public Map<Integer, Employee> findAll() {
		return employeeMap;
	}
	
	public Employee findById(int id) {
		Employee employee = null;
		for (Map.Entry<Integer, Employee> e : employeeMap.entrySet()) {
			if (e.getKey() == id) {
				employee = e.getValue();
			}
		}
		return employee;
	}
	
	public void update(int id, Employee employee) {
		for (Map.Entry<Integer, Employee> e : employeeMap.entrySet()) {
			if (e.getKey() == id) {
				e.getValue().setId(employee.getId());		
			}
		}
	}

	public void delete(int id) {
		Iterator<Entry<Integer, Employee>> it = employeeMap.entrySet().iterator();
		while (it.hasNext()) {
			Entry<Integer, Employee> entry = it.next();
			if (entry.getKey() == id) {
				it.remove();
			}
		}

	}
}
