package com.training.empapp.service;

import java.util.Map;

import com.training.empapp.exception.EmployeeNotFoundException;
import com.training.empapp.model.Employee;
import com.training.empapp.repository.EmployeeRepository;

public class EmployeeService {
	private EmployeeRepository empRepository;

	public EmployeeService() {
		empRepository = new EmployeeRepository();
	}

	public void createEmployee(Employee employee) {
		empRepository.add(employee);
	}

	public Map<Integer, Employee> findAllEmployees() {
		return empRepository.findAll();
	}

	public Employee findEmployeeById(int id) throws EmployeeNotFoundException {
		Employee employee = empRepository.findById(id);
		if (employee == null) {
			throw new EmployeeNotFoundException("Employee is not found");
		} else {
			return employee;
		}
	}

	public void updateEmployee(int id, Employee employee) {
		empRepository.update(id, employee);
	}

	public void deleteEmployee(int id) {
		empRepository.delete(id);
	}
}
