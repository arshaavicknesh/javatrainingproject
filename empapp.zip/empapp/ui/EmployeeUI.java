package com.training.empapp.ui;

import java.util.Map;

import com.training.empapp.exception.EmployeeNotFoundException;
import com.training.empapp.model.Department;
import com.training.empapp.model.Employee;
import com.training.empapp.service.EmployeeService;

public class EmployeeUI {
	public static void main(String[] args) {
		System.out.println("1.Create a New employee");
		EmployeeService employeeService = new EmployeeService();

		Employee employee = new Employee();
		employee.setName("Arshaa");
		employee.setId(235);
		employee.setSalary(20000);
		
		Department department = new Department();
		department.setDepartmentId(105);
		department.setDepartmentName("Support Team");
		employee.setDepartment(department);
		
		employeeService.createEmployee(employee);

		System.out.println("2.Find All Employees");
		Map<Integer, Employee> employees = employeeService.findAllEmployees();
		for (Map.Entry<Integer, Employee> e : employees.entrySet()) {
			System.out.println(e.getKey() + ": " + e.getValue());
		}

		System.out.println("3.Find A Employee By Given Id");
		int id = 234;

		try {
			Employee foundEmployee = employeeService.findEmployeeById(id);
			System.out.println(foundEmployee);
		} catch (EmployeeNotFoundException e) {

		}

		System.out.println("4.Update A Employee By Given Id");
		int updateId = 236;
		Employee newEmployee = new Employee();
		newEmployee.setId(233);
		employeeService.updateEmployee(updateId, newEmployee);

		employees = employeeService.findAllEmployees();
		for (Map.Entry<Integer, Employee> c : employees.entrySet()) {
			System.out.println(c.getKey() + ": " + c.getValue());
		}

		System.out.println("5.Delete A Employee By Given Id");
		int deleteId = 233;
		employeeService.deleteEmployee(deleteId);
		employees = employeeService.findAllEmployees();
		for (Map.Entry<Integer, Employee> c : employees.entrySet()) {
			System.out.println(c.getKey() + ": " + c.getValue());
		}
	}
}
